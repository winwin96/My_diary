from flask import Blueprint, url_for, session
from werkzeug.utils import redirect
from pybo.models import Question

bp = Blueprint('main', __name__, url_prefix='/')

@bp.route('/')
def index():
    user_id = session.get('user_id')
    if user_id == None:
        return redirect(url_for('auth.login'))
    else:
        return redirect(url_for('question._list'))